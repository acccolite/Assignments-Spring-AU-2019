
public class StudentFactory {
	
	 public static Student createStudentOfId(String type)
	    {
	        if (type.contentEquals("newStudent"))
	        {
	            Student student = new Student();
	             
	            student.setStudentId(1001);
	            //student.setStudentName("dummy");
	            
	            //Set designation here
	            student.setStudentName("ANKITA");
	             
	            return student;
	        }
	        else
	        {
	            throw new IllegalArgumentException("Unknown product");
	        }
	    }

}
