
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component("jdbcTemplateDao")
public class JDBCTemplateDAO {
	
@Autowired
	private JdbcTemplate jdbcTemplate;
	
	

public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
}

	public int saveStudent(Student student){
		String query = "insert into student(id,name) values "
				+ "("+student.getStudentId()+",'"+student.getStudentName()+"')";
		return jdbcTemplate.update(query);
	}
	
	//Prepared Statement
		public Boolean saveStudentUsingPreparedStatement(final Student student){
			String query = "insert into student(id,name) values (?,?)";
			return jdbcTemplate.execute(query, new PreparedStatementCallback<Boolean>() {

				public Boolean doInPreparedStatement(PreparedStatement ps)
						throws SQLException, DataAccessException {
					ps.setInt(1, student.getStudentId());
					ps.setString(2, student.getStudentName());
					System.out.println("Student inserted");
					return ps.execute();
				}
			});
		}
		
		public List<Student> getAllEmployeesRowMapper(){  
			 return jdbcTemplate.query("select * from student",new RowMapper<Student>(){  
				 
				 public Student mapRow(ResultSet rs, int rownumber) throws SQLException {  
			        Student e=new Student();  
			        e.setStudentId(rs.getInt(1));
			        e.setStudentName(rs.getString(2));  
			        
			        return e;  
			    }  
			 }); 
		}
	
	

}
