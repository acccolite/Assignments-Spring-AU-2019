
public class Student {

	private int StudentId;
	private String StudentName;
	
	
	public int getStudentId() {
		return StudentId;
	}
	public void setStudentId(int studentId) {
		StudentId = studentId;
	}
	public String getStudentName() {
		return StudentName;
	}
	public void setStudentName(String string) {
		StudentName = string;
	}
	
	
}