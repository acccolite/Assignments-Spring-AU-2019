


import java.util.*;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ApplicationMain {

	public static void main(String[] args) {
		System.out.println("hello");
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		/*
		 * ApplicationContext applicationContext = new
		 * ClassPathXmlApplicationContext("applicationContext.xml"); HelloWorld
		 * helloWorld = (HelloWorld) applicationContext.getBean("helloWorld");
		 * helloWorld.printHello();
		 */
		
		/*HelloWorld helloWorld1 =	(HelloWorld) applicationContext.getBean("helloWorld1");
		helloWorld1.printHello();*/
		
/*		A a =  (A)applicationContext.getBean("a");
		B b =	a.getB();
		System.out.println("B values : "+b.getP() + " "+b.getQ()+" "+b.getR());*/
		
		
		/*B b = (B) applicationContext.getBean("b");
		System.out.println("B values for b: "+b.getP() + " "+b.getQ()+" "+b.getR());
		
		b.setP(4);
		B b1 = (B) applicationContext.getBean("b");
		System.out.println("B values for b1: "+b1.getP() + " "+b1.getQ()+" "+b1.getR());*/
		
		/*Question question = (Question)	applicationContext.getBean("question");		
		
		for(String str : question.list){
			System.out.println(str);
		}*/
		
		Student newStudent = (Student) applicationContext.getBean("newStudent");
        System.out.println("From factory method-> "+newStudent);
        System.out.println(newStudent.getStudentName()+"-->"+newStudent.getStudentId());
         
		
		
		JDBCTemplateDAO jdbc =  applicationContext.getBean(JDBCTemplateDAO.class);
		Student student = new Student();
		student.setStudentId(16);
		student.setStudentName("IBM");
		//jdbc.saveStudent(student);
		jdbc.saveStudentUsingPreparedStatement(student);
		List<Student> list=jdbc.getAllEmployeesRowMapper();
		for(Student e:list)  
		    {
		    	System.out.print(e.getStudentName() +" --> ");
		    	System.out.println(e.getStudentId());
		    
		
		
		
	}
	
}
}
